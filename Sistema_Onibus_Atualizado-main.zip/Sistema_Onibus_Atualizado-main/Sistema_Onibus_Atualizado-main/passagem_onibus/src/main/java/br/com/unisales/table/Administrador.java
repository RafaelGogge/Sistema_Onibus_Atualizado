package br.com.unisales.table;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import br.com.unisales.entities.TipoUsuario;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "administrador")

public class Administrador {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    // @Id indica que 'id' é uma chave primária na tabela do banco de dados..

    @Column(name = "nome", nullable = false, length = 150)
    private String nome;
    // @Column indica que 'nome' é uma coluna na tabela do banco de dados.

    @Column(name = "sexo", nullable = false, length = 1)
    private String sexo;

    @Column(name = "email", nullable = false, length = 150, unique = true)
    private String email;

    @Column(name = "senha", nullable = false, length = 10, unique = true)
    private String senha;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipoUsuario", nullable = false, unique = true)
    private TipoUsuario tipoUsuario;

}
