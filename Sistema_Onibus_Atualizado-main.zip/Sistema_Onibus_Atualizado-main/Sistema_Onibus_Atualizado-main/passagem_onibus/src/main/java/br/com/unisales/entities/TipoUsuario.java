package br.com.unisales.entities;

public enum TipoUsuario {
    PASSAGEIRO,
    VENDEDOR,
    ADMINISTRADOR

}
