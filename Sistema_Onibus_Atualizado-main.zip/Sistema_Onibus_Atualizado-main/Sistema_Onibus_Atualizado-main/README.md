# Apresentação

Olá Caros!

Esse repositório foi criado á fim da elaboração de projeto que consiste em um sistema de gerenciamento de vendas de passagens para viagens da matéria Abstração em Estruturas de Dados, matéria disciplinada pelo Prof. Vito Rodrigues Franzosi referente aos Cursos de T.I da Unisales - Centro Universitário Salesiano.

Foi utilizado as seguintes ferramentas para elaboração do mesmo:

Linguagem de Programação:
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)

IDE: 
![Visual Studio Code](https://img.shields.io/badge/Visual%20Studio%20Code-0078d7.svg?style=for-the-badge&logo=visual-studio-code&logoColor=white)

Versionamento de Código:
![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)

Anotações:
![Notion](https://img.shields.io/badge/Notion-%23000000.svg?style=for-the-badge&logo=notion&logoColor=white)

# Alunos responsáveis pela elaboração desse projeto:

RA 6924106689 / Breno Nunes dos Santos

RA 6924106574 / Emanuel Gonçalves Ferreira

RA 6924106412 / Gabriel Lima Groner

RA 6924106716 / Gleidson de Azevedo Rossmann

RA 6922203723 / Rafael Vieira Gogge

RA 6924106672 / Renan da Cruz Santos

# Professor / Orientador:

Me. Vito Rodrigues Franzosi

# Passo a Passo:

1 - Salve o projeto na raiz do computador C:

2 - Crie uma pasta nomeada de "sqlite"

3 - Em seguida o projeto já está pronto para ser utilizado, clone o repositório para essa pasta gerada na raiz do computador para que não haja erros!

OBS: Em caso de falhas, delete o banco de dados baixado junto com o código java, rode o main novamente e o bando de dados será gerado automaticamente.
